﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Program
    {
        static void Main(string[] args)
        {
            //Numero numeroUno = new Numero();
            //Numero numeroDos = new Numero();
            string Binario = "11";
            string Retorno;
            decimal AuxBinario;
            decimal auxResulatado;

            if (decimal.TryParse(Binario, out AuxBinario))
            {
                auxResulatado = Convert.ToDecimal(AuxBinario);
                Console.Write("numero binario:{0}  -- numero decimal: {1}",Binario ,auxResulatado);
            }
            Console.ReadKey();
        }
    }
}
