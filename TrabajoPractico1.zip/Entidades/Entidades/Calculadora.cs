﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    static class Calculadora
    {
        public static double Operar(Numero Num1, Numero num2, string operador)
        {
            double Resultado=0;

            switch(char.Parse(operador))
            {
                case '+':
                    Resultado = Num1 + num2;
                    break;
                case '-':
                    Resultado = Num1 - num2;
                    break;
                case '*':
                    Resultado = Num1 * num2;
                    break;
                case '/':

                    Resultado = Num1 / num2;
                    break;
                default:
                    break;
            }
            return Resultado;
        }
    }
}
