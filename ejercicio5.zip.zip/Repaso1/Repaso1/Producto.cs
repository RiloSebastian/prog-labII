﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso1
{
    class Producto
    {
        private string CodigoDeBarra;
        private string Marca;
        private float Precio;

        public Producto(string AuxCodigoDeBarra, string AuxMarca, float AuxPrecio)
        {
            this.CodigoDeBarra = AuxCodigoDeBarra;
            this.Marca = AuxMarca;
            this.Precio = AuxPrecio;
        }

        public string GetMarca()
        {
            string Retorno = "---";

            Retorno = this.Marca;

            return Retorno;
        }

        public float GetPrecio()
        {
            float Retorno = -1;

            Retorno = this.Precio;

            return Retorno;
        }

        public static string MostrarProducto(Producto p)
        {
            string Retorno = "---";

            Retorno = "Codigo de Barras: " + (string)p + "  Marca: " + p.GetMarca() + "  Precio: " + p.GetPrecio();

            return Retorno;
        }

        public static explicit operator string(Producto p)
        {
            string Retorno = "---";

            Retorno = p.CodigoDeBarra;

            return Retorno;
        }

        public static bool operator !=(Producto p1, Producto p2)
        {
            if (string.Compare(p1.GetMarca(),p2.GetMarca())!=0)
            {
                return true;
            }
            return false;
        }
        public static bool operator ==(Producto p1, Producto p2)
        {
            if (string.Compare(p1.GetMarca(), p2.GetMarca()) == 0)
            {
                return true;
            }
            return false;
        }

        public static bool operator !=(Producto p1, string Marca)
        {
            if (string.Compare(p1.GetMarca(), Marca) != 0)
            {
                return true;
            }
            return false;
        }
        public static bool operator ==(Producto p1, string Marca)
        {
            if (string.Compare(p1.GetMarca(), Marca) == 0)
            {
                return true;
            }
            return false;
        }
    }
}
