﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Repaso1
{
    class Estante
    {
        private int UbicacionEstante;
        private Producto []productos;
        private int Capacidad;

        private Estante(int capacidad)
        {
            this.Capacidad = capacidad;
            this.productos = new Producto[capacidad];
            for(int i=0;i<capacidad;i++)
            {
                this.productos[i] = null;
            }
        }

        public Estante(int capacidad, int ubicacionEstanteAux)
        {
            this.productos = new Producto[capacidad];
            for (int i = 0; i < capacidad; i++)
            {
                this.productos[i] = null;
            }
            this.UbicacionEstante = ubicacionEstanteAux;
            this.Capacidad = capacidad;
        }

        public Producto[] GetProductos()
        {
            return this.productos;
        }

        public int GetCapacidad()
        {
            return this.Capacidad;
        }

        public int GetUbicacion()
        {
            return this.UbicacionEstante;
        }

        public string MostrarEstante(Estante e)
        {
            string Retorno= "---";
            Producto []auxiliar= e.GetProductos();
            Retorno = e.GetUbicacion().ToString();
            
            for(int i=0;i<=(e.GetCapacidad());i++)
            {
                if(!Object.ReferenceEquals(auxiliar[i],null))
                {
                    Retorno = "\n " + Producto.MostrarProducto(auxiliar[i]);
                }
            }
            return Retorno;
        }

        public static bool operator ==(Estante e, Producto p)
        {
            Producto[] Auxiliar = e.GetProductos();

            for (int i = 0; i <= (e.GetCapacidad()); i++)
            {
                if(Auxiliar[i] == p)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool operator !=(Estante e, Producto p)
        {
            return !(e == p);
        }

        public static bool operator +(Estante e, Producto p)
        {

            Producto []Auxiliar = e.GetProductos();
            int AuxCapacidad=
           
        }
    }
}
