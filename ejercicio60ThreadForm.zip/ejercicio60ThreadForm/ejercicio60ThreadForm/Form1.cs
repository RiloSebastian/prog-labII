﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Timers;

namespace ejercicio60ThreadForm
{
    public partial class Form1 : Form
    {
        private Thread thread;

        public Form1()
        {
            InitializeComponent();
            thread = new Thread(RefrescarHora);
            timer1.Tick += new EventHandler(timer1_Tick);
            thread.Start();
        }

        //usando invoke con threads, refrescio segundero con sleep.
        public void RefrescarHora()
        {
            do
            {
                if (lblHora.InvokeRequired)
                {
                    lblHora.BeginInvoke((MethodInvoker)delegate ()
                    {
                        lblHora.Text = DateTime.Now.ToString();
                    }
                    );
                }
                else
                {
                    lblHora.Text = DateTime.Now.ToString();
                }
                Thread.Sleep(1000);
            } while (true);
        }

        //sin threads. usando timer.
        private void timer1_Tick(object sender, EventArgs e)
        {
            lblHora.Text = DateTime.Now.ToString();
        }
    }
}
