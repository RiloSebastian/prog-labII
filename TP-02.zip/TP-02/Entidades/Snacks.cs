using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    public class Snacks: Producto
    {
        public Snacks(EMarca marca, string patente, ConsoleColor color)
            : base(patente, marca, color)
        {
        }
        /// <summary>
        /// Los snacks tienen 104 calorías
        /// </summary>
        protected override short CantidadCalorias
        {
            get
            {
                return 104;
            }
        }

        public override string Mostrar()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();

            Retorno.AppendLine("SNACKS");
            Retorno.AppendLine(base.Mostrar());
            Retorno.AppendLine(string.Format("CALORIAS : {0}", this.CantidadCalorias));
            Retorno.AppendLine("");
            Retorno.AppendLine("---------------------");

            return Retorno.ToString();
        }
    }
}
