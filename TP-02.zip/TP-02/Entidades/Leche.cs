using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Drawing;

namespace Entidades_2018
{
    public class Leche : Producto
    {
        public enum ETipo
        {
          Entera,
          Descremada
        }

        ETipo tipo;

        /// <summary>
        /// Por defecto, TIPO será ENTERA
        /// </summary>
        /// <param name="marca"></param>
        /// <param name="patente"></param>
        /// <param name="color"></param>
        public Leche(EMarca marca, string patente, ConsoleColor color)
            : base(patente, marca, color)
        {
            tipo = ETipo.Entera;
        }

        public Leche(EMarca marca, string patente, ConsoleColor color, ETipo tipo)
        :base(patente,marca,color)
        {
          this.tipo = tipo;
        }

        /// <summary>
        /// Las leches tienen 20 calorías
        /// </summary>
        protected override short CantidadCalorias
        {
            get
            {
                return this.CantidadCalorias;
            }
        }

        public override sealed string Mostrar()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();

            Retorno.AppendLine("LECHE");
            Retorno.AppendLine(base.Mostrar());
            Retorno.AppendLine(string.Format("CALORIAS : {0}", this.CantidadCalorias));
            Retorno.AppendLine(string.Format("TIPO : " + this.tipo));
            Retorno.AppendLine("");
            Retorno.AppendLine("---------------------");

            return Retorno.ToString();
        }
    }
}
