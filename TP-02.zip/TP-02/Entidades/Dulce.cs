using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    public class Dulce : Producto
    {
        public Dulce(EMarca marca, string patente, ConsoleColor color):base(patente,marca,color)
        {
        }

        /// <summary>
        /// Los dulces tienen 80 calorías
        /// </summary>
        protected override short CantidadCalorias
        {
            get
            {
                return 80;
            }
        }

        public override string Mostrar()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();
            Retorno.AppendLine("DULCE");
            Retorno.AppendLine(base.Mostrar());
            Retorno.AppendLine(string.Format("CALORIAS : {0}", this.CantidadCalorias));
            Retorno.AppendLine("");
            Retorno.AppendLine("---------------------");

            return Retorno.ToString();
    }
    }
}
