using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades_2018
{
    /// <summary>
    /// La clase Producto no deberá permitir que se instancien elementos de este tipo.
    /// </summary>
    public abstract class Producto
    {
        public enum EMarca
        {
            Serenisima,
            Campagnola,
            Arcor,
            Ilolay,
            Sancor,
            Pepsico
        }

        string codigoDeBarras;
        EMarca marca;
        ConsoleColor colorPrimarioEmpaque;

        /// <summary>
        /// ReadOnly: Retornará la cantidad de ruedas del vehículo
        /// </summary>
        protected virtual short CantidadCalorias { get; set; }
        

        public Producto(string patente, EMarca marca, ConsoleColor color)
        {
            this.codigoDeBarras = patente;
            this.marca = marca;
            this.colorPrimarioEmpaque = color;
        }

        /// <summary>
        /// Publica todos los datos del Producto.
        /// </summary>
        /// <returns></returns>
        public virtual string Mostrar()
        {
            StringBuilder Retorno = new StringBuilder();

            Retorno.AppendLine(string.Format("CODIGO DE BARRAS: {0}\r\n", this.codigoDeBarras));
            Retorno.AppendLine(string.Format("MARCA          : {0}\r\n", this.marca.ToString()));
            Retorno.AppendLine(string.Format("COLOR EMPAQUE  : {0}\r\n", this.colorPrimarioEmpaque.ToString()));
            Retorno.AppendLine("---------------------");

            return Retorno.ToString();
        }
        

        public static explicit operator string(Producto p)
        {
            StringBuilder Retorno = new StringBuilder();

            Retorno.AppendLine(string.Format("CODIGO DE BARRAS: {0}\r\n", p.codigoDeBarras));
            Retorno.AppendLine(string.Format("MARCA          : {0}\r\n", p.marca.ToString()));
            Retorno.AppendLine(string.Format("COLOR EMPAQUE  : {0}\r\n", p.colorPrimarioEmpaque.ToString()));
            Retorno.AppendLine("---------------------");

            return Retorno.ToString();
        }

        /// <summary>
        /// Dos productos son iguales si comparten el mismo código de barras
        /// </summary>
        /// <param name="v1"></param>
        /// <param name="v2"></param>
        /// <returns></returns>
        public static bool operator ==(Producto v1, Producto v2)
        {
            if (string.Compare(v1.codigoDeBarras, v2.codigoDeBarras)==0)
            {
                return true;
            }
            return false;
        }
        /// <summary>
        /// Dos productos son distintos si su código de barras es distinto
        /// </summary>
        /// <param name="v1"></param>
        /// <param name="v2"></param>
        /// <returns></returns>
        public static bool operator !=(Producto v1, Producto v2)
        {
            return !(v1 == v2);
        }
    }
}
