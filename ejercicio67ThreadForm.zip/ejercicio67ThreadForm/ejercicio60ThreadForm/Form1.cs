﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Timers;

namespace ejercicio60ThreadForm
{
    public partial class Form1 : Form
    {
        private Temporizador t;
        public Form1()
        {
            InitializeComponent();
            t = new Temporizador();
            t.Intervalo = 1000;
            t.Activo = true;
            
            t.EventoTiempo +=RefrescarHora;
            
        }

        public void RefrescarHora()
        {
            if (lblHora.InvokeRequired)
            {
                lblHora.BeginInvoke((MethodInvoker)delegate ()
                {
                    lblHora.Text = DateTime.Now.ToString();
                }
                );
            }
            else
            {
                lblHora.Text = DateTime.Now.ToString();
            }

        }
    }
}
