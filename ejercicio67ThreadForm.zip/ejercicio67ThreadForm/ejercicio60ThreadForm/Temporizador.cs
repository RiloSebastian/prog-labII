﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace ejercicio60ThreadForm
{
    public delegate void EncargadoTiempo();
    public class Temporizador
    {
        private Thread hilo;
        private int intervalo;
        public event EncargadoTiempo EventoTiempo;

        public bool Activo
        {
            get
            {
                return hilo.IsAlive;
            }
            set
            {
                if (value && !hilo.IsAlive)
                {
                    hilo = new Thread(Corriendo);
                    hilo.Start();
                }
                else if(!value && hilo.IsAlive)
                {
                    hilo.Abort();
                }
            }
        }

        public int Intervalo
        {
            get
            {
                return intervalo;
            }
            set
            {
                intervalo = value;
            }
        }

        public Temporizador()
        {
            hilo = new Thread(Corriendo);
        }


        private void Corriendo()
        {
                do
                {
                    this.EventoTiempo.Invoke();
                    Thread.Sleep(Intervalo);
                
                } while (hilo.IsAlive);
        }
    }
}
