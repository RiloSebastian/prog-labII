﻿namespace MiCalculadora
{
    partial class FormCalculadora
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNumero1 = new System.Windows.Forms.TextBox();
            this.txtNumero2 = new System.Windows.Forms.TextBox();
            this.cbxOperadores = new System.Windows.Forms.ComboBox();
            this.bttnOperar = new System.Windows.Forms.Button();
            this.bttnLimpiar = new System.Windows.Forms.Button();
            this.bttnCerrar = new System.Windows.Forms.Button();
            this.bttnConvertirABinario = new System.Windows.Forms.Button();
            this.bttnConvertirADecimal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNumero1
            // 
            this.txtNumero1.Location = new System.Drawing.Point(12, 46);
            this.txtNumero1.Name = "txtNumero1";
            this.txtNumero1.Size = new System.Drawing.Size(112, 20);
            this.txtNumero1.TabIndex = 0;
            // 
            // txtNumero2
            // 
            this.txtNumero2.Location = new System.Drawing.Point(261, 46);
            this.txtNumero2.Name = "txtNumero2";
            this.txtNumero2.Size = new System.Drawing.Size(110, 20);
            this.txtNumero2.TabIndex = 1;
            // 
            // cbxOperadores
            // 
            this.cbxOperadores.FormattingEnabled = true;
            this.cbxOperadores.Location = new System.Drawing.Point(150, 45);
            this.cbxOperadores.MaxDropDownItems = 4;
            this.cbxOperadores.Name = "cbxOperadores";
            this.cbxOperadores.Size = new System.Drawing.Size(85, 21);
            this.cbxOperadores.TabIndex = 2;
            // 
            // bttnOperar
            // 
            this.bttnOperar.Location = new System.Drawing.Point(12, 100);
            this.bttnOperar.Name = "bttnOperar";
            this.bttnOperar.Size = new System.Drawing.Size(115, 30);
            this.bttnOperar.TabIndex = 3;
            this.bttnOperar.Text = "Operar";
            this.bttnOperar.UseVisualStyleBackColor = true;
            // 
            // bttnLimpiar
            // 
            this.bttnLimpiar.Location = new System.Drawing.Point(150, 100);
            this.bttnLimpiar.Name = "bttnLimpiar";
            this.bttnLimpiar.Size = new System.Drawing.Size(85, 30);
            this.bttnLimpiar.TabIndex = 4;
            this.bttnLimpiar.Text = "Limpiar";
            this.bttnLimpiar.UseVisualStyleBackColor = true;
            // 
            // bttnCerrar
            // 
            this.bttnCerrar.Location = new System.Drawing.Point(256, 100);
            this.bttnCerrar.Name = "bttnCerrar";
            this.bttnCerrar.Size = new System.Drawing.Size(115, 30);
            this.bttnCerrar.TabIndex = 5;
            this.bttnCerrar.Text = "Cerrar";
            this.bttnCerrar.UseVisualStyleBackColor = true;
            // 
            // bttnConvertirABinario
            // 
            this.bttnConvertirABinario.Location = new System.Drawing.Point(12, 154);
            this.bttnConvertirABinario.Name = "bttnConvertirABinario";
            this.bttnConvertirABinario.Size = new System.Drawing.Size(145, 30);
            this.bttnConvertirABinario.TabIndex = 6;
            this.bttnConvertirABinario.Text = "Convertir a binario";
            this.bttnConvertirABinario.UseVisualStyleBackColor = true;
            // 
            // bttnConvertirADecimal
            // 
            this.bttnConvertirADecimal.Location = new System.Drawing.Point(226, 154);
            this.bttnConvertirADecimal.Name = "bttnConvertirADecimal";
            this.bttnConvertirADecimal.Size = new System.Drawing.Size(145, 30);
            this.bttnConvertirADecimal.TabIndex = 7;
            this.bttnConvertirADecimal.Text = "Convertir a decimal";
            this.bttnConvertirADecimal.UseVisualStyleBackColor = true;
            // 
            // FormCalculadora
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 198);
            this.Controls.Add(this.bttnConvertirADecimal);
            this.Controls.Add(this.bttnConvertirABinario);
            this.Controls.Add(this.bttnCerrar);
            this.Controls.Add(this.bttnLimpiar);
            this.Controls.Add(this.bttnOperar);
            this.Controls.Add(this.cbxOperadores);
            this.Controls.Add(this.txtNumero2);
            this.Controls.Add(this.txtNumero1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormCalculadora";
            this.Text = "FormCalculadora";
            this.Load += new System.EventHandler(this.FormCalculadora_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNumero1;
        private System.Windows.Forms.TextBox txtNumero2;
        private System.Windows.Forms.ComboBox cbxOperadores;
        private System.Windows.Forms.Button bttnOperar;
        private System.Windows.Forms.Button bttnLimpiar;
        private System.Windows.Forms.Button bttnCerrar;
        private System.Windows.Forms.Button bttnConvertirABinario;
        private System.Windows.Forms.Button bttnConvertirADecimal;
    }
}