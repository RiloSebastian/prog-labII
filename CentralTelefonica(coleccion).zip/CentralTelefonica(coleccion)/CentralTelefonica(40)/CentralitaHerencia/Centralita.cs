using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Centralita
    {
      private List<Llamada> listaDeLlamadas;
      protected string razonSocial;


      public float GanaciasPorLocal
      {
        get
        {
          return CalcularGanancia(Llamada.TipoLlamada.Local);
        }
      }

      public float GanaciasPorProvincia
      {
        get
        {

          return CalcularGanancia(Llamada.TipoLlamada.Provincial);
        }
      }

      public float GanaciasPorTotal
      {
        get
        {
          return CalcularGanancia(Llamada.TipoLlamada.Todas);
        }
      }


      public List<Llamada> Llamadas
      {
        get
        {
          return listaDeLlamadas;
        }
      }


      public Centralita()
      {
        listaDeLlamadas = new List<Llamada>();
      }

      public Centralita(string nombreDeLaEmpresa) : this()
      {
        this.razonSocial = nombreDeLaEmpresa;
      }

      private void AgregarLlamada(Llamada nuevaLlamada)
      {
          listaDeLlamadas.Add(nuevaLlamada);
      }


      public static bool operator ==(Centralita centralita, Llamada llamada)
      {
        foreach (Llamada l in centralita.Llamadas)
        {
          if (l == llamada)
          {
            return true;
          }
        }
        return false;
      }

      public static bool operator !=(Centralita centralita, Llamada llamada)
      {
        return !(centralita == llamada);
      }

      public static Centralita operator +(Centralita centralita, Llamada llamada)
      {
        if ((centralita != llamada))
        {
          centralita.AgregarLlamada(llamada);
        }
        return centralita;
      }

      private float CalcularGanancia(Llamada.TipoLlamada tipo)
      {
        float retorno = 0;
        if (tipo == Llamada.TipoLlamada.Local)
        {
          foreach (Llamada l in listaDeLlamadas)
          {
            if (l is Local)
            {
              retorno += ((Local)l).CostoLlamada;
            }
          }
        }
        else if (tipo == Llamada.TipoLlamada.Provincial)
        {
          foreach (Llamada l in listaDeLlamadas)
          {
            if (l is Provincial)
            {
              retorno += ((Provincial)l).CostoLlamada;
            }
          }
        }
        else
        {
          foreach (Llamada l in listaDeLlamadas)
          {
            if (l is Local)
            {
              retorno += ((Local)l).CostoLlamada;
            }
            else
            {
              retorno += ((Provincial)l).CostoLlamada;
            }
          }
        }
        return retorno;
      }

      private string Mostrar()
      {
        StringBuilder Retorno;
        Retorno = new StringBuilder();

        Retorno.AppendLine(string.Format("razon social: {0}\n", this.razonSocial));
        Retorno.AppendLine(string.Format("ganancias totales: {0}", this.GanaciasPorTotal));
        Retorno.AppendLine(string.Format("ganancias locales: {0}", this.GanaciasPorLocal));
        Retorno.AppendLine(string.Format("ganancias provinciales: {0}", this.GanaciasPorProvincia));
        Retorno.AppendLine("detalles de llamadas");
        foreach (Llamada l in listaDeLlamadas)
        {
          Retorno.AppendLine("---------------------------");
          Retorno.AppendFormat("{0}", l.ToString());
          Retorno.AppendLine("---------------------------");
        }
        return Retorno.ToString();
      }

      public void OrdenarLlamadas()
      {
        listaDeLlamadas.Sort((x, y) => Llamada.OrdenarPorDuracion(x, y));
      }

      public override string ToString()
      {
          return Mostrar();
      }


    }
}
