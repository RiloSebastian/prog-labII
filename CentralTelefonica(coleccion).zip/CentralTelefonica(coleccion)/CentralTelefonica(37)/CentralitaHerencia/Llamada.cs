﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Llamada
    {
        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }

        protected float duracion;
        protected string numeroDestino;
        protected string numeroOrigen;

        public float Duracion
        {
            get
            {
                return this.duracion;
            }
        }

        public string NroDestino
        {
            get
            {
                return this.numeroDestino;
            }
        }

        public string NroOrigen
        {
            get
            {
                return this.numeroOrigen;
            }
        }

        public Llamada(float duracion, string numeroDestino, string numeroOrigen)
        {
            this.duracion = duracion;
            this.numeroDestino = numeroDestino;
            this.numeroOrigen = numeroOrigen;
        }

        public virtual string Mostrar()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();

            Retorno.AppendLine(string.Format("duracion: {0}",this.Duracion));
            Retorno.AppendLine(string.Format("numero de destino: {0}", this.NroDestino));
            Retorno.AppendLine(string.Format("numero de origen: {0}", this.NroOrigen));
            return Retorno.ToString();
        }

        public static int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            if(llamada1.Duracion > llamada2.Duracion)
            {
                return 1;
            }
            else if(llamada1.Duracion < llamada2.Duracion)
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }


    }
}
