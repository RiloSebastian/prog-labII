﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Local : Llamada
    {
        protected float costo;


        public override float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }
        }

        public Local(Llamada llamada, float costo): this(llamada.NroOrigen,llamada.Duracion,llamada.NroDestino,costo)
        {}

        public Local(string origen,float duracion, string destino ,float costo):base(duracion,destino,origen)
        {
            this.costo = costo;
        }

        protected override string Mostrar()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();

            Retorno.Append(string.Format("{0}",base.Mostrar()));
            Retorno.AppendLine(string.Format("costo de llamada: {0}", this.CostoLlamada));
            return Retorno.ToString();
        }

        public override string ToString()
        {
            return Mostrar();
        }

        private float CalcularCosto()
        {
            float Retorno=0;
            if(this.Duracion < 20)
            {
               Retorno= costo + 5;
            }
            else if(this.Duracion >= 20 && this.Duracion < 45)
            {
                Retorno = costo + 10;
            }
            else
            {
                Retorno = costo + 25;
            }
            return Retorno;
        }

    }
}
