﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Provincial : Llamada
    {
        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3
        }

        protected Franja franjaHoraria;

        public float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();
            }
        }

        public Provincial(Franja miFranja, Llamada llamada): this(llamada.NroOrigen,miFranja,llamada.Duracion,llamada.NroDestino)
        {}

        public Provincial(string origen, Franja miFranja, float duracion, string destino):base(duracion,destino,origen)
        {
            this.franjaHoraria = miFranja;
        }

        private float CalcularCosto()
        {
            double retorno = 0;
            if(franjaHoraria == Franja.Franja_1)
            {
                retorno = Duracion + (Duracion * 0.99);
            }
            else if(franjaHoraria == Franja.Franja_2)
            {
                retorno = Duracion + (Duracion * 1.25);
            }
            else
            {
                retorno = Duracion + (Duracion * 0.66);
            }
            return (float)retorno;
        }

        public override string Mostrar()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();

            Retorno.Append(string.Format("{0}", base.Mostrar()));
            Retorno.AppendLine(string.Format("costo de llamada: {0}", this.CostoLlamada));
            Retorno.AppendLine(string.Format("Franja horaria: {0}", this.franjaHoraria));
            return Retorno.ToString();
        }

    }
}
