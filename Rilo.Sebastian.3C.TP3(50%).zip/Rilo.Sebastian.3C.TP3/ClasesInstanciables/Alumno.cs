﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;

namespace ClasesInstanciables
{
    public sealed class Alumno : Universitario
    {
        public enum EEstadoDeCuenta
        {
            AlDia,
            Deudor,
            Becado
        }

        private Universidad.EClases claseQueToma;
        private EEstadoDeCuenta estadoDeCuenta;

        public Alumno()
        { }

        public Alumno(int id, string nombre, string apellido, string dni, Enacionalidad nacionalidad, Universidad.EClases clasesQueToma)
        {

        }

        public Alumno(int id, string nombre, string apellido, string dni, Enacionalidad nacionalidad, Universidad.EClases clasesQueToma, 
            EEstadoDeCuenta estadoDeCuenta)
        {

        }

        protected override string MostratDatos()
        {
            return base.MostratDatos();
        }

        public static bool operator ==(Alumno a, Universidad.EClases clase)
        {
           
            return false;
        }

        public static bool operator !=(Alumno a, Universidad.EClases clase)
        {
            return !(a == clase);
        }

        protected override string ParticiparEnClase()
        {
            throw new NotImplementedException();
        }
    }
}
