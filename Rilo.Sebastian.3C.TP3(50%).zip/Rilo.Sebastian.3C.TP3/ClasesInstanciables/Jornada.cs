﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesInstanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private Universidad.EClases clase;
        private Profesor instructor;

        public List<Alumno> Alumnos
        {
            get
            {
                return alumnos;
            }
            set
            {

            }
        }

        public Universidad.EClases Clase
        {
            get
            {
                return clase;
            }
            set
            {

            }
        }

        public Profesor Instructor
        {
            get
            {
                return instructor;
            }
            set
            {

            }
        }

        public bool Guardar(Jornada jornada)
        {
            return false;
        }

        private Jornada()
        { }

        public Jornada(Universidad.EClases clase, Profesor instructor)
        {

        }

        public string leer()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();

            return Retorno.ToString();
        }

        public static bool operator ==(Jornada j, Alumno a)
        {

            return false;
        }

        public static bool operator !=(Jornada j, Alumno a)
        {
            return !(j == a);
        }

        public static bool operator +(Jornada j, Alumno a)
        {
            return false;
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
