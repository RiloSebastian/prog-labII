﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClasesInstanciables
{
    public class Universidad
    {
        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }

        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesores;

        public List<Alumno> Alumnos
        {
            get
            {
                return alumnos;
            }
            set
            {

            }
        }

        public List<Profesor> Instructores
        {
            get
            {
                return profesores;
            }
            set
            {

            }
        }

        public List<Jornada> Jornadas
        {
            get
            {
                return alumnos;
            }
            set
            {

            }
        }

        public List<Jornada> this[int i]
        {
            get
            {

            }
            set
            {

            }
        }

        public bool Guardar(Universidad uni)
        {

        }

        public Universidad Leer()
        {

        }

        private string MostrarDatos(Universidad uni)
        {

        }

        public static bool operator ==(Universidad g, Alumno a)
        {
            
            return false;
        }

        public static bool operator ==(Universidad g, Profesor i)
        {
            
            return false;
        }

        public static Profesor operator ==(Universidad u, EClases clase)
        {

            return ;
        }

        public static Universidad operator +(Universidad g, EClases clase)
        {

            
        }

        public static Universidad operator +(Universidad u, Alumno a)
        {

           
        }

        public static Universidad operator +(Universidad u, Profesor i)
        {

            
        }

        public static bool operator !=(Universidad g, Alumno a)
        {
            return !(g==a);
        }

        public static bool operator !=(Universidad g, Profesor i)
        {
            return !(g==i);
        }

        public static Profesor operator !=(Universidad u, EClases clase)
        {
            return ;
        }

        public override string ToString()
        {
            return base.ToString();
        }

        public Universidad()
        {

        }
    }
}
