﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntidadesAbstractas;

namespace ClasesInstanciables
{
    public sealed class Profesor : Universitario
    {
        private Queue<Universidad.EClases> clasesDelDia;
        private Random random;

        private void _ramdomClases()
        {

        }

        protected override string MostratDatos()
        {
            return base.MostratDatos();
        }

        public static bool operator ==(Profesor a, Universidad.EClases clase)
        {

            return false;
        }

        public static bool operator !=(Profesor a, Universidad.EClases clase)
        {
            return !(a == clase);
        }

        protected override string ParticiparEnClase()
        {
            throw new NotImplementedException();
        }

        public Profesor()
        { }

        static Profesor()
        { }

        public Profesor(int id, string nombre, string apellido, string dni, Enacionalidad nacionalidad)
        {

        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
