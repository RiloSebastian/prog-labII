﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EJ68Eventos
{
    public partial class FrmPersona : Form
    {
        private Persona persona;
        private event DelegadoString EventoForm;

        public FrmPersona()
        {
            InitializeComponent();
            this.EventoForm += NotificarCambio;
        }

        private void btnCrear_Click(object sender, EventArgs e)
        {
            if(persona == null)
            {
                persona = new Persona(txtNombre.Text, txtApellido.Text);
                btnCrear.Text = "Actualizar";
                EventoForm.Invoke("se ha instanciado la persona");
            }
            else
            {
                persona.Nombre = txtNombre.Text;
                persona.Apellido = txtApellido.Text;
                EventoForm.Invoke("se ha actualizado la persona");
            }
            EventoForm.Invoke(persona.Mostrar());

        }

        public static void NotificarCambio(string cambio)
        {
            MessageBox.Show(cambio);
        }
    }
}
