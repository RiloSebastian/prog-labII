﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EJ68Eventos
{
    public delegate void DelegadoString(string msj);

    public class Persona
    {
        private string apellido;
        private string nombre;
        public string Nombre
        {
            get
            {
                return nombre;
            }
            set
            {
                this.nombre = value;
            }
        }

        public string Apellido
        {
            get
            {
                return apellido;
            }
            set
            {
                this.apellido = value;
            }
        }

        public Persona(string nombre, string apellido)
        {
            Nombre = nombre;
            Apellido = apellido;
        }

        public string Mostrar()
        {
            return string.Format("{0} {1}", Nombre, Apellido);
        }
    }
}
