using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class Comiqueria
    {
        #region Atributos
        private List<Producto> productos;
        private List<Venta> ventas;
        #endregion

        #region Indexadores
        /// <summary>
        /// obtiene un producto por el valor de su codigo
        /// </summary>
        /// <param name="i">el codigo que se usa para buscar el producto</param>
        /// <returns>el producto en caso de ser encontrado, null en el caso opuesto</returns>
        public Producto this[Guid i]
        {
            get
            {
                foreach(Producto p in this.productos)
                {
                    if(i == (Guid)p)
                    {
                        return p;
                    }
                    
                }
                return null;
            }
        }
        #endregion

        #region Constructores
        /// <summary>
        /// constructor de comiqueria. inicializa las listas de productos y ventas
        /// </summary>
        public Comiqueria()
        {
            this.productos = new List<Producto>();
            this.ventas = new List<Venta>();
        }
        #endregion

        #region Metodos
        /// <summary>
        /// sobrecarga de operador == verifica si un producto se encuentra dentro de una comiqueria
        /// </summary>
        /// <param name="comiqueria">la comiqueria donde se va a buscar el producto</param>
        /// <param name="producto">el producto que se quiere buscar</param>
        /// <returns>TRUE si se encuentra, FALSE en caso contrario</returns>
        public static bool operator ==(Comiqueria comiqueria, Producto producto)
        {
            foreach(Producto productoAuxiliar in comiqueria.productos)
            {
                if(string.Compare(producto.Descripcion,productoAuxiliar.Descripcion)==0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// sobrecarga de operador == verifica si un producto NO se encuentra dentro de una comiqueria
        /// </summary>
        /// <param name="comiqueria">la comiqueria donde se va a buscar el producto</param>
        /// <param name="producto">el producto que se quiere buscar</param>
        /// <returns>como se reutiliza codigo, devuelve lo contrario a la sobrecarga ==</returns>
        public static bool operator !=(Comiqueria comiqueria, Producto producto)
        {
            return !(comiqueria == producto);
        }

        /// <summary>
        /// sobrecarga de operador +. agreaga un producto a la lista en comiqueria
        /// </summary>
        /// <param name="comiqueria">donde se encuentra la lista donde se va a agregar el producto</param>
        /// <param name="producto">el producto que se quiere agregar</param>
        /// <returns>la comiqueria con la lista de productos, modificada o no</returns>
        public static Comiqueria operator +(Comiqueria comiqueria, Producto producto)
        {

            if(comiqueria != producto)
            {
                comiqueria.productos.Add(producto);
            }
            return comiqueria;
        }

        /// <summary>
        /// metodo que vende una unidad de producto
        /// </summary>
        /// <param name="producto">el producto que se va a vender</param>
        public void Vender(Producto producto)
        {
            Vender(producto, 1);
        }

        /// <summary>
        /// metodo que vender una cantidad de unidades de un producto
        /// </summary>
        /// <param name="producto">el producto que se quiere vender</param>
        /// <param name="cantidad">la cantidad de unidades que se quieren vender</param>
        public void Vender(Producto producto, int cantidad)
        {
            Venta v;
            v = new Venta(producto, cantidad);
            ventas.Add(v);
        }

        /// <summary>
        /// arma una lista con la escripcion breve de cada venta
        /// </summary>
        /// <returns>la lista de descripciones</returns>
        public string ListarVentas()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();
            
            foreach(Venta v in this.ventas)
            {
                Retorno.AppendLine(string.Format("{0}", v.ObtenerDescripcionBreve()));
            }
            return Retorno.ToString();
        }

        /// <summary>
        /// ordena los elementos de la lista 
        /// </summary>
        /// <param name="v1">el primer porducto en la lista ventas</param>
        /// <param name="v2">el segundo producto en la lista ventas</param>
        /// <returns>un valor indicando cual de los 2 productos tiene una fecha anterior al otro o si son iguales</returns>
        private int OrdenarElementos(Venta v1, Venta v2)
        {
            int Retorno=0;
            if(v1.Fecha > v2.Fecha)
            {
                return 1;
            }
            else if(v1.Fecha < v2.Fecha)
            {
                return -1;
            }
            return Retorno;
        }

        /// <summary>
        /// genera una coleccion tipo diccionario y guarda en ella la descripcion de todos los productos de la
        /// comiqueria utilizando como clave su codigo
        /// </summary>
        /// <returns>el dicccionario ya generado</returns>
        public Dictionary<Guid,string> ListarProductos()
        {
            Dictionary<Guid, string> diccionario;
            diccionario = new Dictionary<Guid, string>();
            foreach(Producto p in productos)
            {
                diccionario.Add((Guid)p, p.Descripcion);
            }
            return diccionario;
        }
        #endregion
  }
}
