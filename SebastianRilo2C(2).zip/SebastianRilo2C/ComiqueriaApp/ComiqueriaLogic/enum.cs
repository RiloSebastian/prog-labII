using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
        /// <summary>
        /// enumerado de tipos de commics
        /// </summary>
        public enum TipoComic
        {
            Occidental,
            Oriental
        }
}
