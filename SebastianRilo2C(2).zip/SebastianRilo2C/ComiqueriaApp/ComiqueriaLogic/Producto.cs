using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public abstract class Producto
    {
        private Guid codigo;
        private string descripcion;
        private double precio;
        private int stock;

        /// <summary>
        /// obtiene el valor del campo descripcion
        /// </summary>
        public string Descripcion
        {
            get
            {
                return descripcion;
            }
        }


        /// <summary>
        /// obtiene el valor del campo precio
        /// </summary>
        public double Precio
        {
            get
            {
                return precio;
            }
        }

        /// <summary>
        /// obtiene el valor del campo stock
        /// </summary>
        public int Stock
        {
            get
            {
                return stock;
            }
            set
            {
                if(value >= 0)
                {
                    stock = value;
                }
            }
        }

        /// <summary>
        /// constructor de instancia para el producto
        /// </summary>
        /// <param name="descripcion"> parametro que contiene la descripcion del producto</param>
        /// <param name="stock"> parametro que contiene el stock del producto</param>
        /// <param name="precio"> parametro que contiene el precio del producto</param>
        protected Producto(string descripcion, int stock, double precio)
        {
            this.descripcion = descripcion;
            Stock = stock;
            this.precio = precio;
            this.codigo = Guid.NewGuid();
        }

        /// <summary>
        /// sobrecarga de operador para obtener el valor del campo codigo de un producto
        /// </summary>
        /// <param name="p">el preoducto del que se quiere obtener el valor</param>
        public static explicit operator Guid(Producto p)
        {
            return p.codigo;
        }

        /// <summary>
        /// genera un texto a partir de un stringBuilder con informacion del producto
        /// </summary>
        /// <returns>el texto ya generado </returns>
        public override string ToString()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();
            Retorno.AppendLine(string.Format(" descripcion: {0}", Descripcion));
            Retorno.AppendLine(string.Format(" codigo: {0}", this.codigo));
            Retorno.AppendLine(string.Format(" precio: ${0}", Precio));
            Retorno.AppendLine(string.Format(" stock: {0} unidades", Stock));

            return Retorno.ToString();
        }


    }
}
