using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComiqueriaLogic;

namespace VentasForm
{
  public partial class formVentas : Form
  {
        private Producto producto;
        private Comiqueria comiqueria;

    /// <summary>
    /// constructor por defecto
    /// </summary>
    public formVentas()
    {
      InitializeComponent();
    }

    /// <summary>
    /// constructor para generar el formulario desde PrincipalForm
    /// </summary>
    /// <param name="comiqueriaLista">un objeto de clase comiqueria</param>
    /// <param name="productoAVender">el producto que se desea vender</param>
    public formVentas(Comiqueria comiqueriaLista, Producto productoAVender)
    {
            InitializeComponent();
            comiqueria = comiqueriaLista;
            producto = productoAVender;
            lblDescripcionBreve.Text = producto.Descripcion;
            lblPrecioFinal.Text = string.Format("Precio Final: ${0:#,0.00}", producto.Precio);
      
    }

    /// <summary>
    /// al cambiar la cantidad seleccionada cambia el precio final de la venta
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void numericUpDownCantidad_ValueChanged(object sender, EventArgs e)
    {
      lblPrecioFinal.Text = string.Format("Precio Final: ${0:#,0.00}", (producto.Precio)*(int)numericUpDownCantidad.Value);
    }

    /// <summary>
    /// realiza la venta si es posible
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void btnVender_Click(object sender, EventArgs e)
    {
       if(numericUpDownCantidad.Value > producto.Stock)
      {
        MessageBox.Show("Te pasaste de la cantidad maxima de stock para este producto. disminuir la cantidad", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
      }
      else
      {
        comiqueria.Vender(producto);
        this.DialogResult =DialogResult.OK;
        this.Close();
      }
    }

    /// <summary>
    /// se cancela la venta 
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void btnCancelar_Click(object sender, EventArgs e)
    {
      this.Close();
    }
  }
}
