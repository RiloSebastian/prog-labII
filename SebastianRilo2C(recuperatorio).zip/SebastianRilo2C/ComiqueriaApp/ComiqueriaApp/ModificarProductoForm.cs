﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ComiqueriaLogic;

namespace ComiqueriaApp
{
    public partial class ModificarProductoForm : Form
    {
        private Producto producto;
        private Comiqueria comiqueria;

        public ModificarProductoForm()
        {
            InitializeComponent();   
        }


        public ModificarProductoForm(Comiqueria comiqueriaLista, Producto productoAModificar)
        {
            InitializeComponent();
            comiqueria = comiqueriaLista;
            producto = productoAModificar;
            lblDescripccion.Text = producto.Descripcion;
            txtPrecioActual.Text = string.Format("${0:#,0.00}", producto.Precio);

        }

        private void btnModificar_Click(object sender, EventArgs e)
        {
            double resultado;
            if(double.TryParse(txtNuevoPrecio.Text, out resultado))
            {
               DialogResult result= MessageBox.Show("", "queres modificar este producto?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if(result== DialogResult.Yes)
                {
                    producto.Precio= resultado;
                    this.Close();
                }
            }
            else
            {
                lblError.Text = "error. Debe ingresar un precio valido";
            }
            
        }

        private void txtNuevoPrecio_TextChanged(object sender, EventArgs e)
        {
            lblError.Text = "";
        }
    }
}
