﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ComiqueriaLogic;

namespace ComprobanteLogic
{
    public class Factura: Comprobante
    {
        public enum TipoFactura
        {
            A,
            B,
            C,
            E
        }
        private DateTime fechaVencimiento;
        private TipoFactura tipoFactura;


        public Factura(Venta venta, int diasParaVencimiento, TipoFactura tipoFactura):base(venta)
        {
            this.fechaVencimiento = DateTime.Now.AddDays(diasParaVencimiento);
            this.tipoFactura = tipoFactura;
        }

        public Factura(Venta venta, TipoFactura tipoFactura):this(venta,15,tipoFactura)
        { }

        public override bool Equals(object obj)
        {
            if(obj is Factura)
            {
                Factura auxiliar;
                auxiliar = (Factura)obj;
                if(auxiliar.fechaEmision == fechaEmision && auxiliar.tipoFactura == tipoFactura)
                {
                    return true;
                }   
            }
            return false;
        }

        public override string generarComprobante()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();

            Retorno.AppendLine(string.Format("        FACTURA {0}", tipoFactura));
            Retorno.Append(string.Format("     fecha Emision {0}", fechaEmision));
            Retorno.AppendLine(string.Format("  fecha Vencimiento {0}", fechaVencimiento));
            Retorno.Append(string.Format("        Producto {0}", ((Producto)Venta).Descripcion));
            Retorno.Append(string.Format("      cantidad {0}", Venta.Cantidad));
            Retorno.AppendLine(string.Format("   precio Unitario ${0:#,0.00}", ((Producto)Venta).Precio));
            Retorno.Append(string.Format("        subtotal ${0:#,0.00}",(((Producto)Venta).Precio)*Venta.Cantidad));
            Retorno.Append(string.Format("      importe IVA ${0:#,0.00}", ((((Producto)Venta).Precio) * Venta.Cantidad)*0.21));
            Retorno.Append(string.Format("   importe total ${0:#,0.00}", ((Producto)Venta).Precio+=((((Producto)Venta).Precio)*Venta.Cantidad)*0.21));
            return Retorno.ToString();
        }


    }
}
