using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class Figura: Producto
    {
        #region atributos
        private double altura;
        #endregion

        #region constructores
        /// <summary>
        /// constructor de instancia de la figura
        /// </summary>
        /// <param name="stock">parametro cuyo valor se le va a asignar al campo stock</param>
        /// <param name="precio">parametro cuyo valor se le va a asignar al campo precio</param>
        /// <param name="altura">parametro cuyo valor se le va a asignar al campo altura</param>
        public Figura(int stock, double precio, double altura): this(string.Format("Figura {0} cm", altura),stock, precio, altura)
        {
            this.altura = altura;
        }

        /// <summary>
        /// sobrecarga de constructor de instancia de la figura
        /// </summary>
        /// <param name="descripcion">parametro cuyo valor se le va a asignar al campo descripcion</param>
        /// <param name="stock">parametro cuyo valor se le va a asignar al campo stock</param>
        /// <param name="precio">parametro cuyo valor se le va a asignar al campo precio</param>
        /// <param name="altura">parametro cuyo valor se le va a asignar al campo altura</param>
        public Figura(string descripcion, int stock, double precio, double altura) : base(descripcion, stock, precio)
        {
           
        }
    #endregion

        #region metodos
        /// <summary>
        /// override que indica una descripcion breve de la figura
        /// </summary>
        /// <returns>un string con la descripcion</returns>
        public override string ToString()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();
            Retorno.AppendLine(string.Format("{0}", base.ToString()));
            Retorno.AppendLine(string.Format(" altura: {0} cm", this.altura));

            return Retorno.ToString();
        }
        #endregion
  }
}
