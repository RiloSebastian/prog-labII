using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public sealed class Venta
    {
        #region Atributos
        private DateTime fecha;
        private int cantidad;
        static int procentajeIva;
        private double precioFinal;
        private Producto producto;
        #endregion

        #region Propiedades
        /// <summary>
        /// devuelve el valor del campo fecha
        /// </summary>
        internal DateTime Fecha
        {
            get
            {
                return this.fecha;
            }
        }

        /// <summary>
        /// devuelve el valor del campo cantidad
        /// </summary>
        public int Cantidad
        {
            get
            {
                return this.cantidad;
            }
            
        }

        #endregion

        #region Constructores
        /// <summary>
        /// constructor de instancia para la venta
        /// </summary>
        /// <param name="producto">el preoducto que se va a vender</param>
        /// <param name="cantidad">la cantidad de unidades que se van a vender</param>
        internal Venta(Producto producto, int cantidad)
        {
            this.producto = producto;
            this.cantidad = cantidad;
            this.Vender(cantidad);
        }
        
        /// <summary>
        /// constructor estatico de venta. inicializa el IVA en 21
        /// </summary>
        static Venta()
        {
            procentajeIva = 21;
        }
    #endregion

        #region Operadores
        /// <summary>
        /// convierte una venta a su producto
        /// </summary>
        /// <param name="v">la venta</param>
        public static explicit operator Producto(Venta v)
        {
            return v.producto;
        }
        #endregion

        #region Metodos
    /// <summary>
    /// realiza una venta 
    /// </summary>
    /// <param name="cantidad">la cantidad de unidades que se van a vender de un producto</param>
    private void Vender(int cantidad)
        {
            producto.Stock = (producto.Stock - cantidad);
            this.fecha = DateTime.Now;
            this.precioFinal = CalcularPrecioFinal(producto.Precio, cantidad);
        }

        /// <summary>
        /// calcula el precio final de la venta
        /// </summary>
        /// <param name="precioUnidad">el valor del producto por unidad</param>
        /// <param name="cantidad">cantidad de unidades que se van a vender</param>
        /// <returns>el valor del precio final de la venta</returns>
        public static double CalcularPrecioFinal(double precioUnidad, int cantidad)
        {
            double Retorno;

            Retorno = precioUnidad * cantidad;
            Retorno += (Retorno * procentajeIva) / 100;
            return Retorno;
        }

        /// <summary>
        /// genera una descripcion breve de la venta realizada
        /// </summary>
        /// <returns>la descripcion de la venta</returns>
        public string ObtenerDescripcionBreve()
        {
            string Retorno;
            Retorno = string.Format("fecha: {0} -- descripcion: {1} -- precioFinal: ${2:#,0.00}", this.Fecha,
                this.producto.Descripcion, this.precioFinal);
            return Retorno;
        }
        #endregion
  }
}
