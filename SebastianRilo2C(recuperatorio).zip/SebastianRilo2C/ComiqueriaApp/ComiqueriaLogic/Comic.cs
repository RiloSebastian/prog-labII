using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ComiqueriaLogic
{
    public class Comic: Producto
    {
        #region Atributos
        private string autor;
        private TipoComic tipoComic;
        #endregion

        #region Enumerados
        /// <summary>
        /// enumerado de tipos de commics
        /// </summary>
        public enum TipoComic
        {
          Occidental,
          Oriental
        }
        #endregion

        #region Constructores
        /// <summary>
        /// constructor de instancia para Comic
        /// </summary>
        /// <param name="descripcion">parametro que contiene la descripcion del comic</param>
        /// <param name="stock">parametro que contiene el stock del comic</param>
        /// <param name="precio">parametro que contiene el precio del comic</param>
        /// <param name="autor">parametro que contiene el autor del comic</param>
        /// <param name="tipoComic">parametro que contiene el tipo del comic</param>
        public Comic(string descripcion, int stock, double precio, string autor, TipoComic tipoComic)
            :base(descripcion,stock,precio)
        {
            this.autor = autor;
            this.tipoComic = tipoComic;
        }
        #endregion

        #region Metodos
        /// <summary>
        /// genera una descripcion del producto
        /// </summary>
        /// <returns>el texto ya generado</returns>
        public override string ToString()
        {
            StringBuilder Retorno;
            Retorno = new StringBuilder();
            Retorno.AppendLine(string.Format("{0}", base.ToString()));
            Retorno.AppendLine(string.Format(" autor: {0}", this.autor));
            Retorno.AppendLine(string.Format(" tipo de comic: {0}", this.tipoComic));

            return Retorno.ToString();
        }
        #endregion

  }
}
